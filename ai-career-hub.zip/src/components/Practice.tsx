import React, { useState } from 'react';
import { UserProfile, Simulation, SimulationEvaluation, InterviewEvaluation } from '../types';
import { 
  generateSimulation, 
  generateInterviewQuestion, 
  evaluateInterviewAnswer, 
  evaluateSimulationAnswer 
} from '../lib/gemini';
import { 
  Briefcase, 
  MessageSquare, 
  Play, 
  Loader2, 
  CheckCircle2, 
  AlertCircle,
  ArrowRight,
  Trophy,
  Star,
  ChevronRight,
  Sparkles,
  BarChart3,
  Users,
  Clock,
  FileText,
  Presentation,
  Handshake,
  Megaphone,
  Target,
  TrendingUp,
  RotateCcw
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

interface PracticeProps {
  user: UserProfile;
  addXP: (amount: number) => void;
}

export default function Practice({ user, addXP }: PracticeProps) {
  const [mode, setMode] = useState<'selection' | 'simulation' | 'interview'>('selection');
  const [isLoading, setIsLoading] = useState(false);
  
  // Simulation State
  const [simulation, setSimulation] = useState<Simulation | null>(null);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [showFeedback, setShowFeedback] = useState(false);
  const [simulationEvaluation, setSimulationEvaluation] = useState<SimulationEvaluation | null>(null);

  // Interview State
  const [interviewQuestion, setInterviewQuestion] = useState<string | null>(null);
  const [answer, setAnswer] = useState('');
  const [evaluation, setEvaluation] = useState<InterviewEvaluation | null>(null);

  const startSimulation = async () => {
    setIsLoading(true);
    setMode('simulation');
    try {
      const data = await generateSimulation(user.goal || 'Kinh doanh');
      setSimulation(data);
      setSelectedOption(null);
      setShowFeedback(false);
      setSimulationEvaluation(null);
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSimulationSubmit = async (optionId: number) => {
    setSelectedOption(optionId);
    setIsLoading(true);
    try {
      const choice = simulation?.options.find(o => o.id === optionId)?.text || '';
      const data = await evaluateSimulationAnswer(simulation!.context, simulation!.task, choice, simulation!.industry);
      setSimulationEvaluation(data);
      setShowFeedback(true);
      addXP(data.score * 2);
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const startInterview = async () => {
    setIsLoading(true);
    setMode('interview');
    try {
      const data = await generateInterviewQuestion(user.goal || 'Thực tập sinh', user.year);
      setInterviewQuestion(data.question);
      setAnswer('');
      setEvaluation(null);
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleInterviewSubmit = async () => {
    if (!answer.trim()) return;
    setIsLoading(true);
    try {
      const data = await evaluateInterviewAnswer(interviewQuestion!, answer);
      setEvaluation(data);
      addXP(data.score * 5);
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-text-main tracking-tight">Thực tập ảo & Phỏng vấn AI</h1>
          <p className="text-text-sub font-medium mt-1">Rèn luyện kỹ năng thực tế thông qua các tình huống giả lập doanh nghiệp.</p>
        </div>
        {mode !== 'selection' && (
          <button 
            onClick={() => setMode('selection')}
            className="text-sm font-bold text-text-sub hover:text-primary transition-colors flex items-center gap-2"
          >
            <RotateCcw size={16} /> Quay lại lựa chọn
          </button>
        )}
      </div>

      <AnimatePresence mode="wait">
        {mode === 'selection' && (
          <motion.div 
            key="selection"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="grid grid-cols-1 md:grid-cols-2 gap-8"
          >
            <button 
              onClick={startSimulation}
              className="group bg-surface p-10 rounded-[24px] border border-border hover:border-primary transition-all text-left relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 -mr-16 -mt-16 rotate-45 group-hover:scale-110 transition-transform" />
              <div className="w-16 h-16 bg-primary/10 text-primary rounded-[18px] flex items-center justify-center mb-8 group-hover:scale-110 transition-transform shadow-sm">
                <Briefcase size={32} />
              </div>
              <h3 className="text-2xl font-black text-text-main mb-3">Sàn Thực Tập Ảo</h3>
              <p className="text-text-sub text-[15px] leading-relaxed mb-8">Xử lý hóa đơn, khách hàng khó tính, lập kế hoạch kinh doanh, thuyết trình trước sếp...</p>
              <div className="flex items-center gap-2 text-primary font-black text-[14px] uppercase tracking-wider">
                Bắt đầu thực tập <ArrowRight size={18} />
              </div>
            </button>

            <button 
              onClick={startInterview}
              className="group bg-surface p-10 rounded-[24px] border border-border hover:border-secondary transition-all text-left relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-secondary/5 -mr-16 -mt-16 rotate-45 group-hover:scale-110 transition-transform" />
              <div className="w-16 h-16 bg-secondary/10 text-secondary rounded-[18px] flex items-center justify-center mb-8 group-hover:scale-110 transition-transform shadow-sm">
                <MessageSquare size={32} />
              </div>
              <h3 className="text-2xl font-black text-text-main mb-3">Phỏng vấn ảo AI</h3>
              <p className="text-text-sub text-[15px] leading-relaxed mb-8">Luyện tập trả lời phỏng vấn với HR Manager ảo và nhận đánh giá chi tiết về kỹ năng.</p>
              <div className="flex items-center gap-2 text-secondary font-black text-[14px] uppercase tracking-wider">
                Bắt đầu phỏng vấn <ArrowRight size={18} />
              </div>
            </button>
          </motion.div>
        )}

        {mode === 'simulation' && (
          <motion.div 
            key="simulation"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-4xl mx-auto w-full"
          >
            {isLoading && !simulationEvaluation ? (
              <div className="card text-center space-y-6 py-20">
                <Loader2 className="animate-spin mx-auto text-primary" size={48} />
                <div>
                  <h3 className="text-xl font-black text-text-main">AI đang thiết lập văn phòng ảo...</h3>
                  <p className="text-text-sub font-medium mt-2">Đang chuẩn bị tình huống thực tế cho bạn.</p>
                </div>
              </div>
            ) : simulation && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-6">
                  <div className="card space-y-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <span className={cn(
                          "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest",
                          simulation.difficulty === 'Easy' ? "bg-green-100 text-green-600" :
                          simulation.difficulty === 'Medium' ? "bg-orange-100 text-orange-600" :
                          "bg-red-100 text-red-600"
                        )}>
                          {simulation.difficulty}
                        </span>
                        <h2 className="text-xl font-black text-text-main">{simulation.title}</h2>
                      </div>
                      <div className="text-text-sub">
                        <Briefcase size={20} />
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <div className="p-5 bg-bg rounded-[18px] border border-border">
                        <h4 className="text-[11px] font-black text-text-sub uppercase tracking-wider mb-2 flex items-center gap-2">
                          <Users size={14} /> Bối cảnh doanh nghiệp
                        </h4>
                        <p className="text-text-main text-[15px] leading-relaxed">{simulation.context}</p>
                      </div>
                      <div className="p-5 bg-primary/5 rounded-[18px] border border-primary/10">
                        <h4 className="text-[11px] font-black text-primary uppercase tracking-wider mb-2 flex items-center gap-2">
                          <Target size={14} /> Nhiệm vụ của bạn
                        </h4>
                        <p className="text-text-main font-bold text-[15px]">{simulation.task}</p>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <h4 className="text-[14px] font-black text-text-main uppercase tracking-tight mb-2">Bạn sẽ xử lý như thế nào?</h4>
                      {simulation.options.map((option) => (
                        <button
                          key={option.id}
                          disabled={showFeedback || isLoading}
                          onClick={() => handleSimulationSubmit(option.id)}
                          className={cn(
                            "w-full p-5 rounded-[18px] border text-left transition-all flex items-center justify-between group",
                            selectedOption === option.id 
                              ? (simulationEvaluation?.isCorrect ? "bg-secondary text-white border-secondary shadow-lg shadow-secondary/20" : "bg-red-500 text-white border-red-500 shadow-lg shadow-red-500/20")
                              : "bg-surface border-border text-text-main hover:border-primary/30 hover:bg-bg"
                          )}
                        >
                          <span className="font-bold text-[15px]">{option.text}</span>
                          {isLoading && selectedOption === option.id ? (
                            <Loader2 size={20} className="animate-spin" />
                          ) : (
                            <ChevronRight size={20} className={cn("transition-transform", selectedOption === option.id ? "translate-x-1" : "group-hover:translate-x-1")} />
                          )}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="space-y-6">
                  <AnimatePresence>
                    {showFeedback && simulationEvaluation && (
                      <motion.div 
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        className={cn(
                          "card p-6 space-y-6 border-2",
                          simulationEvaluation.isCorrect ? "border-secondary/30" : "border-red-200"
                        )}
                      >
                        <div className="flex items-center justify-between">
                          <div className={cn(
                            "flex items-center gap-2 font-black text-[14px] uppercase tracking-wider",
                            simulationEvaluation.isCorrect ? "text-secondary" : "text-red-600"
                          )}>
                            {simulationEvaluation.isCorrect ? <CheckCircle2 size={24} /> : <AlertCircle size={24} />}
                            {simulationEvaluation.isCorrect ? 'Tuyệt vời!' : 'Cần cải thiện'}
                          </div>
                          <div className="text-3xl font-black text-text-main">{simulationEvaluation.score}</div>
                        </div>
                        
                        <div className="space-y-4">
                          <div>
                            <h4 className="text-[11px] font-black text-text-sub uppercase tracking-wider mb-2">Phân tích chuyên gia</h4>
                            <p className="text-text-main text-[14px] leading-relaxed">
                              {simulationEvaluation.explanation}
                            </p>
                          </div>

                          <div className="bg-primary/5 p-4 rounded-[14px] border border-primary/10">
                            <h4 className="text-[11px] font-black text-primary uppercase tracking-wider mb-1 flex items-center gap-1">
                              <Sparkles size={14} /> Pro Tip
                            </h4>
                            <p className="text-[13px] text-text-main italic leading-relaxed">{simulationEvaluation.proTip}</p>
                          </div>

                          <div>
                            <h4 className="text-[11px] font-black text-text-sub uppercase tracking-wider mb-2">Kỹ năng được cộng</h4>
                            <div className="flex flex-wrap gap-2">
                              {simulationEvaluation.skillsImproved.map((skill, i) => (
                                <span key={i} className="px-2 py-1 bg-bg border border-border rounded-lg text-[11px] font-bold text-text-sub">
                                  {skill}
                                </span>
                              ))}
                            </div>
                          </div>
                        </div>

                        <button 
                          onClick={startSimulation}
                          className="btn btn-primary w-full"
                        >
                          Tình huống tiếp theo
                        </button>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <div className="card bg-bg border-none">
                    <h4 className="font-bold text-text-main mb-4">Mô-đun thực tập</h4>
                    <div className="space-y-2">
                      {[
                        { icon: FileText, label: 'Xử lý hóa đơn' },
                        { icon: Users, label: 'Khách hàng khó tính' },
                        { icon: Clock, label: 'Quản lý Deadline' },
                        { icon: BarChart3, label: 'Kế hoạch kinh doanh' },
                        { icon: Presentation, label: 'Thuyết trình' },
                        { icon: Handshake, label: 'Đàm phán' },
                        { icon: Megaphone, label: 'Marketing' },
                      ].map((m, i) => (
                        <div key={i} className="flex items-center gap-3 p-3 rounded-xl hover:bg-surface transition-colors cursor-default">
                          <m.icon size={16} className="text-text-sub" />
                          <span className="text-[13px] font-medium text-text-sub">{m.label}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        )}

        {mode === 'interview' && (
          <motion.div 
            key="interview"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl mx-auto w-full"
          >
            {isLoading && !evaluation ? (
              <div className="card text-center space-y-6 py-20">
                <Loader2 className="animate-spin mx-auto text-secondary" size={48} />
                <div>
                  <h3 className="text-xl font-black text-text-main">HR đang chuẩn bị câu hỏi...</h3>
                  <p className="text-text-sub font-medium mt-2">Đang thiết lập phòng phỏng vấn ảo.</p>
                </div>
              </div>
            ) : interviewQuestion && (
              <div className="space-y-6">
                <div className="card space-y-8">
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 rounded-[20px] bg-bg flex items-center justify-center overflow-hidden border border-border shadow-sm">
                      <img src="https://picsum.photos/seed/hr-manager/200/200" alt="HR" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                    </div>
                    <div>
                      <div className="text-[11px] font-black text-secondary uppercase tracking-widest">HR Manager</div>
                      <h3 className="text-xl font-black text-text-main">Phỏng vấn vị trí {user.goal}</h3>
                    </div>
                  </div>

                  <div className="bg-text-main text-white p-8 rounded-[24px] relative shadow-xl shadow-text-main/20">
                    <div className="absolute -top-2 left-8 w-4 h-4 bg-text-main rotate-45" />
                    <p className="text-lg font-bold leading-relaxed italic">"{interviewQuestion}"</p>
                  </div>

                  {!evaluation ? (
                    <div className="space-y-4">
                      <textarea
                        value={answer}
                        onChange={(e) => setAnswer(e.target.value)}
                        placeholder="Nhập câu trả lời của bạn tại đây..."
                        className="w-full h-40 bg-bg border border-border rounded-[20px] p-6 text-[15px] focus:outline-none focus:border-secondary transition-all resize-none font-medium"
                      />
                      <button
                        onClick={handleInterviewSubmit}
                        disabled={!answer.trim() || isLoading}
                        className="btn btn-secondary w-full py-4 text-lg"
                      >
                        {isLoading ? <Loader2 className="animate-spin mx-auto" /> : 'Gửi câu trả lời'}
                      </button>
                    </div>
                  ) : (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="space-y-8"
                    >
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="card bg-bg border-none text-center">
                          <div className="text-4xl font-black text-secondary mb-1">{evaluation.score}</div>
                          <div className="text-[11px] font-black text-text-sub uppercase tracking-wider">Overall Score</div>
                        </div>
                        <div className="md:col-span-2 card bg-secondary/5 border-secondary/20">
                          <h4 className="text-[11px] font-black text-secondary uppercase tracking-wider mb-2">Nhận xét từ HR</h4>
                          <p className="text-text-main text-[14px] leading-relaxed font-medium">{evaluation.feedback}</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-4">
                          <h4 className="text-[14px] font-black text-text-main uppercase tracking-tight flex items-center gap-2">
                            <Trophy size={18} className="text-accent" /> Điểm mạnh
                          </h4>
                          <div className="space-y-2">
                            {evaluation.strengths.map((s, i) => (
                              <div key={i} className="flex items-center gap-3 p-3 bg-green-50 rounded-xl text-[13px] font-bold text-green-700">
                                <CheckCircle2 size={16} /> {s}
                              </div>
                            ))}
                          </div>
                        </div>
                        <div className="space-y-4">
                          <h4 className="text-[14px] font-black text-text-main uppercase tracking-tight flex items-center gap-2">
                            <TrendingUp size={18} className="text-primary" /> Cần cải thiện
                          </h4>
                          <div className="space-y-2">
                            {evaluation.improvements.map((s, i) => (
                              <div key={i} className="flex items-center gap-3 p-3 bg-blue-50 rounded-xl text-[13px] font-bold text-blue-700">
                                <Sparkles size={16} /> {s}
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>

                      <button 
                        onClick={startInterview}
                        className="btn btn-secondary w-full py-4"
                      >
                        Thử câu hỏi khác
                      </button>
                    </motion.div>
                  )}
                </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

