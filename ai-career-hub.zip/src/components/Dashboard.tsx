import React, { useState, useEffect } from 'react';
import { 
  Trophy, 
  Target, 
  TrendingUp, 
  Award, 
  Clock, 
  CheckCircle2, 
  Sparkles,
  ChevronRight,
  Edit3,
  Flame,
  Zap
} from 'lucide-react';
import { motion } from 'motion/react';
import { UserProfile } from '../types';
import { generateDailyTip } from '../lib/gemini';
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip 
} from 'recharts';
import { cn } from '../lib/utils';

interface DashboardProps {
  user: UserProfile;
  updateUser: (updates: Partial<UserProfile>) => void;
}

const MOCK_CHART_DATA = [
  { day: 'Mon', xp: 120 },
  { day: 'Tue', xp: 250 },
  { day: 'Wed', xp: 180 },
  { day: 'Thu', xp: 320 },
  { day: 'Fri', xp: 450 },
  { day: 'Sat', xp: 380 },
  { day: 'Sun', xp: 520 },
];

export default function Dashboard({ user, updateUser }: DashboardProps) {
  const [dailyTip, setDailyTip] = useState<string>('');
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState(user);

  useEffect(() => {
    const fetchTip = async () => {
      try {
        const result = await generateDailyTip(user);
        setDailyTip(result.tip);
      } catch (error) {
        console.error(error);
      }
    };
    fetchTip();
  }, [user.goal]);

  const handleSaveProfile = () => {
    updateUser(editForm);
    setIsEditing(false);
  };

  const xpToNextLevel = user.level * 1000;
  const xpProgress = (user.xp % 1000) / 10;

  return (
    <div className="space-y-8">
      {/* Header & Quick Stats */}
      <div className="flex flex-col lg:flex-row gap-6">
        <div className="flex-1 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-black text-text-main tracking-tight">Chào mừng trở lại, {user.name}!</h1>
              <p className="text-text-sub font-medium mt-1">Hôm nay bạn muốn chinh phục mục tiêu nào?</p>
            </div>
            <button 
              onClick={() => setIsEditing(true)}
              className="p-2 hover:bg-bg rounded-xl border border-border transition-all text-text-sub hover:text-primary"
            >
              <Edit3 size={20} />
            </button>
          </div>

          {/* AI Coach Banner */}
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-primary/5 border border-primary/10 rounded-[20px] p-6 relative overflow-hidden group"
          >
            <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 -mr-16 -mt-16 rotate-45 group-hover:scale-110 transition-transform" />
            <div className="flex items-start gap-4 relative">
              <div className="w-12 h-12 bg-primary text-white rounded-[14px] flex items-center justify-center shrink-0 shadow-lg shadow-primary/20">
                <Sparkles size={24} />
              </div>
              <div>
                <h3 className="text-[14px] font-black text-primary uppercase tracking-wider mb-1">AI Career Coach</h3>
                <p className="text-text-main text-[15px] font-medium leading-relaxed italic">
                  "{dailyTip || 'Đang chuẩn bị lời khuyên cho bạn...'}"
                </p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Level & XP Card */}
        <div className="lg:w-80 card bg-text-main text-white border-none shadow-xl shadow-text-main/20">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-white/10 rounded-lg flex items-center justify-center">
                <Zap size={18} className="text-primary" />
              </div>
              <span className="text-[12px] font-bold uppercase tracking-widest opacity-60">Level {user.level}</span>
            </div>
            <div className="flex items-center gap-1 text-primary font-black">
              <Flame size={16} />
              <span>{user.streak} Day Streak</span>
            </div>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between text-[14px] font-bold">
              <span>{user.xp} XP</span>
              <span className="opacity-60">{xpToNextLevel} XP</span>
            </div>
            <div className="h-3 bg-white/10 rounded-full overflow-hidden">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${xpProgress}%` }}
                className="h-full bg-primary shadow-[0_0_10px_rgba(37,99,235,0.5)]"
              />
            </div>
            <p className="text-[11px] font-medium opacity-60 text-center">Còn {xpToNextLevel - user.xp} XP nữa để lên Level {user.level + 1}</p>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Tasks Done', value: user.completedTasks, icon: CheckCircle2, color: 'text-secondary', bg: 'bg-secondary/10' },
          { label: 'Focus Time', value: `${user.focusTime}m`, icon: Clock, color: 'text-primary', bg: 'bg-primary/10' },
          { label: 'XP Points', value: user.xp, icon: TrendingUp, color: 'text-accent', bg: 'bg-accent/10' },
          { label: 'Badges', value: user.badges.length, icon: Award, color: 'text-purple-500', bg: 'bg-purple-500/10' },
        ].map((stat, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="card flex items-center gap-4 hover:border-primary/30 transition-all"
          >
            <div className={cn("w-12 h-12 rounded-[14px] flex items-center justify-center shrink-0", stat.bg, stat.color)}>
              <stat.icon size={24} />
            </div>
            <div>
              <p className="text-[11px] font-bold text-text-sub uppercase tracking-wider">{stat.label}</p>
              <h4 className="text-2xl font-black text-text-main">{stat.value}</h4>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Progress Chart */}
        <div className="lg:col-span-2 card">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h3 className="font-bold text-text-main">Tiến độ học tập</h3>
              <p className="text-[11px] text-text-sub uppercase font-bold tracking-wider">XP Gained this week</p>
            </div>
            <select className="bg-bg border border-border rounded-lg px-3 py-1.5 text-[12px] font-bold focus:outline-none focus:border-primary">
              <option>Last 7 Days</option>
              <option>Last 30 Days</option>
            </select>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={MOCK_CHART_DATA}>
                <defs>
                  <linearGradient id="colorXp" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563EB" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#2563EB" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                <XAxis 
                  dataKey="day" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#64748B', fontSize: 12, fontWeight: 600 }}
                  dy={10}
                />
                <YAxis hide />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1E293B', border: 'none', borderRadius: '12px', color: '#fff' }}
                  itemStyle={{ color: '#fff', fontWeight: 'bold' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="xp" 
                  stroke="#2563EB" 
                  strokeWidth={3}
                  fillOpacity={1} 
                  fill="url(#colorXp)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Achievements / Badges */}
        <div className="card">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="font-bold text-text-main">Thành tích</h3>
              <p className="text-[11px] text-text-sub uppercase font-bold tracking-wider">Your Badges</p>
            </div>
            <button className="text-[12px] font-bold text-primary hover:underline">View All</button>
          </div>
          <div className="grid grid-cols-3 gap-4">
            {[
              { id: '1', name: 'Early Bird', icon: '🌅', color: 'bg-orange-100' },
              { id: '2', name: 'Focus King', icon: '👑', color: 'bg-blue-100' },
              { id: '3', name: 'Task Master', icon: '🎯', color: 'bg-green-100' },
              { id: '4', name: 'Streak 7', icon: '🔥', color: 'bg-red-100' },
              { id: '5', name: 'AI Explorer', icon: '🤖', color: 'bg-purple-100' },
              { id: '6', name: 'Intern Pro', icon: '💼', color: 'bg-slate-100' },
            ].map((badge) => (
              <div key={badge.id} className="flex flex-col items-center gap-2 group cursor-help">
                <div className={cn(
                  "w-14 h-14 rounded-2xl flex items-center justify-center text-2xl transition-all group-hover:scale-110 group-hover:rotate-3 shadow-sm",
                  user.badges.includes(badge.id) ? badge.color : "bg-bg grayscale opacity-40"
                )}>
                  {badge.icon}
                </div>
                <span className="text-[10px] font-bold text-text-sub text-center leading-tight">{badge.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Edit Profile Modal */}
      {isEditing && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-surface rounded-[24px] p-8 w-full max-w-md border border-border shadow-2xl"
          >
            <h2 className="text-2xl font-black text-text-main mb-6">Chỉnh sửa hồ sơ</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-[12px] font-bold text-text-sub uppercase mb-1.5">Họ và tên</label>
                <input 
                  type="text" 
                  value={editForm.name}
                  onChange={(e) => setEditForm({...editForm, name: e.target.value})}
                  className="w-full bg-bg border border-border rounded-xl px-4 py-2.5 text-[14px] focus:outline-none focus:border-primary"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[12px] font-bold text-text-sub uppercase mb-1.5">Năm học</label>
                  <select 
                    value={editForm.year}
                    onChange={(e) => setEditForm({...editForm, year: e.target.value})}
                    className="w-full bg-bg border border-border rounded-xl px-4 py-2.5 text-[14px] focus:outline-none focus:border-primary"
                  >
                    <option>Năm 1</option>
                    <option>Năm 2</option>
                    <option>Năm 3</option>
                    <option>Năm 4</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[12px] font-bold text-text-sub uppercase mb-1.5">GPA hiện tại</label>
                  <input 
                    type="text" 
                    value={editForm.gpa}
                    onChange={(e) => setEditForm({...editForm, gpa: e.target.value})}
                    className="w-full bg-bg border border-border rounded-xl px-4 py-2.5 text-[14px] focus:outline-none focus:border-primary"
                  />
                </div>
              </div>
              <div>
                <label className="block text-[12px] font-bold text-text-sub uppercase mb-1.5">Mục tiêu nghề nghiệp</label>
                <input 
                  type="text" 
                  value={editForm.goal}
                  onChange={(e) => setEditForm({...editForm, goal: e.target.value})}
                  className="w-full bg-bg border border-border rounded-xl px-4 py-2.5 text-[14px] focus:outline-none focus:border-primary"
                />
              </div>
            </div>
            <div className="flex gap-3 mt-8">
              <button 
                onClick={() => setIsEditing(false)}
                className="flex-1 py-3 rounded-xl font-bold text-text-sub hover:bg-bg transition-colors"
              >
                Hủy
              </button>
              <button 
                onClick={handleSaveProfile}
                className="flex-1 py-3 bg-primary text-white rounded-xl font-bold hover:bg-primary/90 transition-colors shadow-lg shadow-primary/20"
              >
                Lưu thay đổi
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
