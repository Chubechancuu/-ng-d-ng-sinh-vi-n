import React, { useState } from 'react';
import { 
  FileText, 
  Download, 
  Plus, 
  Trash2, 
  Briefcase, 
  GraduationCap, 
  Award, 
  Mail, 
  Phone, 
  Globe, 
  MapPin,
  Sparkles,
  Layout,
  Eye,
  Type,
  Palette,
  CheckCircle2,
  AlertCircle,
  UserCircle,
  Edit3
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { UserProfile, CVData } from '../types';
import { cn } from '../lib/utils';

interface CareerProps {
  user: UserProfile;
}

export default function Career({ user }: CareerProps) {
  const [cvData, setCvData] = useState<CVData>({
    personalInfo: {
      fullName: user.name,
      email: '',
      phone: '',
      address: '',
      summary: `Sinh viên ${user.year} ngành Kinh tế với mục tiêu trở thành ${user.goal}. GPA hiện tại: ${user.gpa}.`
    },
    education: [
      { school: 'Trường Đại học Kinh tế', degree: 'Cử nhân', major: user.goal, startDate: '2022', endDate: '2026' }
    ],
    experience: [],
    skills: ['Microsoft Office', 'English'],
    projects: []
  });

  const [activeSection, setActiveSection] = useState<'edit' | 'preview'>('edit');

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-text-main tracking-tight">CV Builder Pro</h1>
          <p className="text-text-sub font-medium mt-1">Tạo CV chuyên nghiệp chuẩn ATS dành riêng cho sinh viên kinh tế.</p>
        </div>
        <div className="flex bg-surface p-1 rounded-xl border border-border">
          <button 
            onClick={() => setActiveSection('edit')}
            className={cn(
              "flex items-center gap-2 px-4 py-2 rounded-lg text-[13px] font-bold transition-all",
              activeSection === 'edit' ? "bg-primary text-white shadow-md" : "text-text-sub hover:text-text-main"
            )}
          >
            <Edit3 size={16} /> Chỉnh sửa
          </button>
          <button 
            onClick={() => setActiveSection('preview')}
            className={cn(
              "flex items-center gap-2 px-4 py-2 rounded-lg text-[13px] font-bold transition-all",
              activeSection === 'preview' ? "bg-primary text-white shadow-md" : "text-text-sub hover:text-text-main"
            )}
          >
            <Eye size={16} /> Xem trước
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Editor Sidebar */}
        <div className={cn(
          "lg:col-span-4 space-y-6",
          activeSection === 'preview' && "hidden lg:block"
        )}>
          <div className="card space-y-6">
            <h3 className="font-black text-text-main uppercase tracking-tight flex items-center gap-2">
              <UserCircle size={20} className="text-primary" /> Thông tin cá nhân
            </h3>
            <div className="space-y-4">
              <div>
                <label className="block text-[11px] font-black text-text-sub uppercase tracking-wider mb-1.5">Họ và tên</label>
                <input 
                  type="text" 
                  value={cvData.personalInfo.fullName}
                  onChange={(e) => setCvData({...cvData, personalInfo: {...cvData.personalInfo, fullName: e.target.value}})}
                  className="w-full bg-bg border border-border rounded-xl px-4 py-2 text-[14px] focus:outline-none focus:border-primary"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] font-black text-text-sub uppercase tracking-wider mb-1.5">Email</label>
                  <input 
                    type="email" 
                    value={cvData.personalInfo.email}
                    onChange={(e) => setCvData({...cvData, personalInfo: {...cvData.personalInfo, email: e.target.value}})}
                    className="w-full bg-bg border border-border rounded-xl px-4 py-2 text-[14px] focus:outline-none focus:border-primary"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-black text-text-sub uppercase tracking-wider mb-1.5">Số điện thoại</label>
                  <input 
                    type="text" 
                    value={cvData.personalInfo.phone}
                    onChange={(e) => setCvData({...cvData, personalInfo: {...cvData.personalInfo, phone: e.target.value}})}
                    className="w-full bg-bg border border-border rounded-xl px-4 py-2 text-[14px] focus:outline-none focus:border-primary"
                  />
                </div>
              </div>
              <div>
                <label className="block text-[11px] font-black text-text-sub uppercase tracking-wider mb-1.5">Tóm tắt mục tiêu</label>
                <textarea 
                  value={cvData.personalInfo.summary}
                  onChange={(e) => setCvData({...cvData, personalInfo: {...cvData.personalInfo, summary: e.target.value}})}
                  className="w-full bg-bg border border-border rounded-xl px-4 py-2 text-[14px] focus:outline-none focus:border-primary h-24 resize-none"
                />
              </div>
            </div>
          </div>

          <div className="card space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="font-black text-text-main uppercase tracking-tight flex items-center gap-2">
                <Briefcase size={20} className="text-secondary" /> Kinh nghiệm
              </h3>
              <button className="p-1.5 bg-secondary/10 text-secondary rounded-lg hover:bg-secondary/20 transition-all">
                <Plus size={16} />
              </button>
            </div>
            <p className="text-[12px] text-text-sub italic text-center py-4">Chưa có kinh nghiệm nào được thêm.</p>
          </div>

          <div className="card space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="font-black text-text-main uppercase tracking-tight flex items-center gap-2">
                <Palette size={20} className="text-accent" /> Kỹ năng
              </h3>
              <button className="p-1.5 bg-accent/10 text-accent rounded-lg hover:bg-accent/20 transition-all">
                <Plus size={16} />
              </button>
            </div>
            <div className="flex flex-wrap gap-2">
              {cvData.skills.map((skill, i) => (
                <div key={i} className="px-3 py-1 bg-bg border border-border rounded-lg text-[12px] font-bold text-text-sub flex items-center gap-2">
                  {skill} <Trash2 size={12} className="cursor-pointer hover:text-red-500" />
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Preview Area */}
        <div className={cn(
          "lg:col-span-8",
          activeSection === 'edit' && "hidden lg:block"
        )}>
          <div className="sticky top-24">
            <div className="flex items-center justify-between mb-4 px-4">
              <div className="flex items-center gap-2 text-[12px] font-bold text-text-sub uppercase tracking-widest">
                <Layout size={16} /> Professional Template
              </div>
              <button className="flex items-center gap-2 px-6 py-2.5 bg-text-main text-white rounded-xl text-[14px] font-black hover:bg-black transition-all shadow-lg shadow-text-main/20">
                <Download size={18} /> Tải xuống PDF
              </button>
            </div>

            {/* CV Document */}
            <div className="bg-white shadow-2xl rounded-[2px] min-h-[1000px] w-full max-w-[800px] mx-auto overflow-hidden flex flex-col md:flex-row text-[#334155]">
              {/* Left Column */}
              <div className="w-full md:w-[280px] bg-[#F1F5F9] p-10 space-y-10">
                <div className="space-y-4">
                  <div className="w-32 h-32 bg-slate-300 rounded-full mx-auto overflow-hidden border-4 border-white shadow-sm">
                    <img src={`https://picsum.photos/seed/${user.name}/200/200`} alt="Avatar" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                  </div>
                  <div className="text-center">
                    <h2 className="text-xl font-black text-slate-900 leading-tight">{cvData.personalInfo.fullName}</h2>
                    <p className="text-[13px] font-bold text-primary uppercase tracking-wider mt-1">{user.goal}</p>
                  </div>
                </div>

                <div className="space-y-6">
                  <h3 className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] border-b border-slate-200 pb-2">Liên hệ</h3>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3 text-[12px] font-medium">
                      <Mail size={14} className="text-primary" /> {cvData.personalInfo.email || 'email@example.com'}
                    </div>
                    <div className="flex items-center gap-3 text-[12px] font-medium">
                      <Phone size={14} className="text-primary" /> {cvData.personalInfo.phone || '0123 456 789'}
                    </div>
                    <div className="flex items-center gap-3 text-[12px] font-medium">
                      <MapPin size={14} className="text-primary" /> {cvData.personalInfo.address || 'Hà Nội, Việt Nam'}
                    </div>
                  </div>
                </div>

                <div className="space-y-6">
                  <h3 className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] border-b border-slate-200 pb-2">Kỹ năng</h3>
                  <div className="space-y-4">
                    {cvData.skills.map((skill, i) => (
                      <div key={i} className="space-y-1.5">
                        <div className="flex justify-between text-[11px] font-bold">
                          <span>{skill}</span>
                          <span>80%</span>
                        </div>
                        <div className="h-1 bg-slate-200 rounded-full overflow-hidden">
                          <div className="h-full bg-primary w-[80%]" />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-6">
                  <h3 className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] border-b border-slate-200 pb-2">Ngoại ngữ</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between text-[12px] font-bold">
                      <span>Tiếng Anh</span>
                      <span className="text-primary">IELTS 7.5</span>
                    </div>
                    <div className="flex justify-between text-[12px] font-bold">
                      <span>Tiếng Việt</span>
                      <span className="text-primary">Bản ngữ</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Column */}
              <div className="flex-1 p-12 space-y-12 bg-white">
                <section className="space-y-4">
                  <h3 className="text-[14px] font-black text-slate-900 uppercase tracking-[0.15em] flex items-center gap-3">
                    <span className="w-8 h-[2px] bg-primary" /> Giới thiệu
                  </h3>
                  <p className="text-[14px] leading-relaxed text-slate-600 font-medium">
                    {cvData.personalInfo.summary}
                  </p>
                </section>

                <section className="space-y-6">
                  <h3 className="text-[14px] font-black text-slate-900 uppercase tracking-[0.15em] flex items-center gap-3">
                    <span className="w-8 h-[2px] bg-primary" /> Học vấn
                  </h3>
                  <div className="space-y-6">
                    {cvData.education.map((edu, i) => (
                      <div key={i} className="relative pl-6 border-l-2 border-slate-100">
                        <div className="absolute -left-[9px] top-0 w-4 h-4 bg-white border-2 border-primary rounded-full" />
                        <div className="flex justify-between items-start mb-1">
                          <h4 className="font-black text-slate-900 text-[15px]">{edu.school}</h4>
                          <span className="text-[11px] font-bold text-slate-400">{edu.startDate} - {edu.endDate}</span>
                        </div>
                        <p className="text-[13px] font-bold text-primary">{edu.degree} - {edu.major}</p>
                        <p className="text-[12px] text-slate-500 mt-2 font-medium">GPA: {user.gpa}/4.0</p>
                      </div>
                    ))}
                  </div>
                </section>

                <section className="space-y-6">
                  <h3 className="text-[14px] font-black text-slate-900 uppercase tracking-[0.15em] flex items-center gap-3">
                    <span className="w-8 h-[2px] bg-primary" /> Kinh nghiệm
                  </h3>
                  {cvData.experience.length === 0 ? (
                    <div className="p-8 border-2 border-dashed border-slate-100 rounded-2xl text-center">
                      <p className="text-[13px] text-slate-400 font-medium">Hãy thêm kinh nghiệm làm việc hoặc hoạt động ngoại khóa để làm nổi bật CV của bạn.</p>
                    </div>
                  ) : (
                    <div className="space-y-8">
                      {/* Experience items would go here */}
                    </div>
                  )}
                </section>

                <section className="space-y-6">
                  <h3 className="text-[14px] font-black text-slate-900 uppercase tracking-[0.15em] flex items-center gap-3">
                    <span className="w-8 h-[2px] bg-primary" /> Giải thưởng
                  </h3>
                  <div className="grid grid-cols-1 gap-4">
                    <div className="flex items-start gap-4 p-4 bg-slate-50 rounded-xl">
                      <Award className="text-accent shrink-0" size={20} />
                      <div>
                        <h4 className="text-[13px] font-black text-slate-900">Sinh viên 5 tốt cấp Trường</h4>
                        <p className="text-[11px] text-slate-500 font-bold">Năm học 2023 - 2024</p>
                      </div>
                    </div>
                  </div>
                </section>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

