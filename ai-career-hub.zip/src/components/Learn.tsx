import React, { useState, useEffect } from 'react';
import { 
  BookOpen, 
  CheckCircle2, 
  Circle, 
  Sparkles, 
  Loader2, 
  ChevronRight,
  Target,
  Award,
  Zap,
  Star,
  Trophy
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { UserProfile, RoadmapItem } from '../types';
import { generateRoadmap } from '../lib/gemini';
import { cn } from '../lib/utils';

interface LearnProps {
  user: UserProfile;
}

export default function Learn({ user }: LearnProps) {
  const [roadmap, setRoadmap] = useState<RoadmapItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [activeYear, setActiveYear] = useState('Năm 1');

  useEffect(() => {
    const fetchRoadmap = async () => {
      setIsLoading(true);
      try {
        const result = await generateRoadmap(user.year, user.gpa, user.goal);
        setRoadmap(result.roadmap);
        setActiveYear(user.year || 'Năm 1');
      } catch (error) {
        console.error(error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchRoadmap();
  }, [user.goal, user.year]);

  const activeData = roadmap.find(r => r.year === activeYear) || roadmap[0];

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-text-main tracking-tight">Lộ trình phát triển 4 năm</h1>
          <p className="text-text-sub font-medium mt-1">Lộ trình cá nhân hóa dựa trên mục tiêu {user.goal}.</p>
        </div>
        <button 
          onClick={() => window.location.reload()}
          className="flex items-center gap-2 px-4 py-2 bg-primary/10 text-primary rounded-xl text-[14px] font-bold hover:bg-primary/20 transition-all"
        >
          <Zap size={18} /> Cập nhật lộ trình
        </button>
      </div>

      {isLoading ? (
        <div className="card py-20 text-center space-y-6">
          <Loader2 className="animate-spin mx-auto text-primary" size={48} />
          <div>
            <h3 className="text-xl font-black text-text-main">AI đang phân tích thị trường...</h3>
            <p className="text-text-sub font-medium mt-2">Đang thiết kế lộ trình tối ưu cho mục tiêu {user.goal}.</p>
          </div>
        </div>
      ) : roadmap.length > 0 ? (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Year Selection */}
          <div className="space-y-3">
            {roadmap.map((item) => (
              <button
                key={item.year}
                onClick={() => setActiveYear(item.year)}
                className={cn(
                  "w-full p-5 rounded-[20px] border text-left transition-all group relative overflow-hidden",
                  activeYear === item.year 
                    ? "bg-primary text-white border-primary shadow-lg shadow-primary/20" 
                    : "bg-surface border-border text-text-sub hover:border-primary/30 hover:bg-bg"
                )}
              >
                <div className="flex items-center justify-between relative z-10">
                  <span className="font-black text-lg tracking-tight">{item.year}</span>
                  <ChevronRight size={18} className={cn("transition-transform", activeYear === item.year ? "translate-x-1" : "group-hover:translate-x-1")} />
                </div>
                <div className={cn(
                  "text-[11px] font-bold uppercase tracking-widest mt-1 relative z-10",
                  activeYear === item.year ? "text-white/70" : "text-text-sub"
                )}>
                  {item.year === user.year ? 'Năm hiện tại' : 'Kế hoạch'}
                </div>
                {activeYear === item.year && (
                  <motion.div layoutId="year-bg" className="absolute inset-0 bg-primary" />
                )}
              </button>
            ))}
          </div>

          {/* Year Content */}
          <div className="lg:col-span-3 space-y-8">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeYear}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                {/* Advice Card */}
                <div className="card bg-primary/5 border-primary/10 p-8 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-40 h-40 bg-primary/5 -mr-20 -mt-20 rounded-full" />
                  <div className="flex items-start gap-4 relative">
                    <div className="w-12 h-12 bg-primary text-white rounded-2xl flex items-center justify-center shrink-0 shadow-lg shadow-primary/20">
                      <Sparkles size={24} />
                    </div>
                    <div>
                      <h3 className="text-[14px] font-black text-primary uppercase tracking-wider mb-2">Lời khuyên chiến lược</h3>
                      <p className="text-text-main text-lg font-bold leading-relaxed italic">
                        "{activeData.advice}"
                      </p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {/* Tasks */}
                  <div className="card space-y-6">
                    <div className="flex items-center justify-between">
                      <h3 className="font-black text-text-main uppercase tracking-tight flex items-center gap-2">
                        <Target size={20} className="text-primary" /> Nhiệm vụ trọng tâm
                      </h3>
                      <span className="text-[11px] font-black text-text-sub bg-bg px-2 py-1 rounded uppercase">
                        {activeData.tasks.length} Tasks
                      </span>
                    </div>
                    <div className="space-y-3">
                      {activeData.tasks.map((task, i) => (
                        <div key={i} className="flex items-start gap-4 p-4 bg-bg rounded-[18px] border border-border group hover:border-primary/30 transition-all">
                          <div className="mt-1 text-text-sub group-hover:text-primary transition-colors">
                            <Circle size={18} />
                          </div>
                          <span className="text-[14px] font-bold text-text-main leading-tight">{task}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Skills */}
                  <div className="card space-y-6">
                    <h3 className="font-black text-text-main uppercase tracking-tight flex items-center gap-2">
                      <Award size={20} className="text-secondary" /> Kỹ năng cần đạt
                    </h3>
                    <div className="space-y-4">
                      {activeData.skills?.map((skill, i) => (
                        <div key={i} className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="text-[14px] font-bold text-text-main">{skill}</span>
                            <Star size={14} className="text-accent fill-accent" />
                          </div>
                          <div className="h-2 bg-bg rounded-full overflow-hidden">
                            <motion.div 
                              initial={{ width: 0 }}
                              animate={{ width: '100%' }}
                              transition={{ delay: i * 0.2, duration: 1 }}
                              className="h-full bg-secondary"
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                    
                    <div className="mt-8 p-6 bg-secondary/5 rounded-[24px] border border-secondary/10 text-center">
                      <div className="w-12 h-12 bg-secondary/10 text-secondary rounded-full flex items-center justify-center mx-auto mb-3">
                        <Trophy size={24} />
                      </div>
                      <h4 className="font-black text-secondary text-[14px] uppercase tracking-wider">Phần thưởng hoàn thành</h4>
                      <p className="text-[12px] text-text-sub font-medium mt-1">Hoàn thành tất cả nhiệm vụ để nhận 500 XP và Huy hiệu {activeYear}</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      ) : (
        <div className="card py-20 text-center">
          <p className="text-text-sub font-medium">Không thể tải lộ trình. Vui lòng thử lại sau.</p>
        </div>
      )}
    </div>
  );
}
