import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export const model = "gemini-3-flash-preview";

export async function generateRoadmap(year: string, gpa: string, goal: string) {
  const prompt = `Bạn là một chuyên gia tư vấn nghề nghiệp cao cấp ngành Kinh tế. Hãy tạo một lộ trình (roadmap) 4 năm đại học chi tiết cho sinh viên:
  - Năm hiện tại: ${year}
  - GPA: ${gpa}
  - Mục tiêu: ${goal}
  
  Yêu cầu lộ trình chia theo từng năm. Mỗi năm bao gồm:
  - tasks: Danh sách 4-5 nhiệm vụ cụ thể, thực tế (VD: "Học khóa Power BI cơ bản", "Tham gia CLB Chứng khoán").
  - advice: Lời khuyên chiến lược để đạt mục tiêu.
  - skills: Danh sách 3 kỹ năng trọng tâm cần đạt được trong năm đó.
  
  Trả về JSON:
  {
    "roadmap": [
      { "year": "Năm 1", "tasks": [...], "advice": "...", "skills": ["Skill A", "Skill B"] },
      ...
    ]
  }`;

  const response = await ai.models.generateContent({
    model,
    contents: prompt,
    config: { responseMimeType: "application/json" }
  });

  return JSON.parse(response.text);
}

export async function evaluateSimulationAnswer(context: string, task: string, choice: string, industry: string) {
  const prompt = `Ngành: ${industry}
  Bối cảnh: ${context}
  Nhiệm vụ: ${task}
  Lựa chọn của người dùng: ${choice}
  
  Hãy phân tích sâu sắc lựa chọn này dưới góc độ chuyên gia kinh tế/doanh nghiệp. Trả về JSON:
  {
    "isCorrect": boolean,
    "score": 0-100,
    "explanation": "Giải thích chi tiết tại sao lựa chọn này tốt hoặc chưa tốt trong thực tế doanh nghiệp",
    "proTip": "Mẹo chuyên gia để xử lý tình huống này tốt hơn",
    "skillsImproved": ["Kỹ năng A", "Kỹ năng B"]
  }`;

  const response = await ai.models.generateContent({
    model,
    contents: prompt,
    config: { responseMimeType: "application/json" }
  });

  return JSON.parse(response.text);
}

const SIMULATION_MODULES = [
  "Xử lý hóa đơn sai",
  "Khách hàng khó tính",
  "Trễ deadline team",
  "Lập kế hoạch kinh doanh",
  "Phân tích lỗ lãi",
  "Thuyết trình trước sếp",
  "Deal giá với đối tác",
  "Marketing thất bại cần cứu"
];

export async function generateSimulation(industry: string) {
  const module = SIMULATION_MODULES[Math.floor(Math.random() * SIMULATION_MODULES.length)];
  const prompt = `Tạo một tình huống giả lập thực tập thực tế cho ngành ${industry}, tập trung vào chủ đề: ${module}.
  Tình huống nên bao gồm:
  - Tiêu đề tình huống
  - Bối cảnh (Context) chi tiết
  - Nhiệm vụ cụ thể (Task)
  - Độ khó: Easy, Medium, hoặc Hard
  - 3 lựa chọn cách xử lý (Options) với feedback sơ bộ
  
  Trả về JSON:
  {
    "title": "...",
    "context": "...",
    "task": "...",
    "difficulty": "Easy/Medium/Hard",
    "options": [
      { "id": 1, "text": "...", "feedback": "..." },
      ...
    ]
  }`;

  const response = await ai.models.generateContent({
    model,
    contents: prompt,
    config: { responseMimeType: "application/json" }
  });

  return { ...JSON.parse(response.text), industry };
}

export async function generateInterviewQuestion(role: string, level: string) {
  const prompt = `Bạn là một HR Manager tại một tập đoàn kinh tế lớn đang phỏng vấn ứng viên cho vị trí ${role} cấp độ ${level}. 
  Hãy đưa ra 1 câu hỏi phỏng vấn hóc búa, tình huống thực tế.
  
  Trả về JSON:
  {
    "question": "..."
  }`;

  const response = await ai.models.generateContent({
    model,
    contents: prompt,
    config: { responseMimeType: "application/json" }
  });

  return JSON.parse(response.text);
}

export async function evaluateInterviewAnswer(question: string, answer: string) {
  const prompt = `Đánh giá câu trả lời phỏng vấn sau dưới góc độ HR chuyên nghiệp:
  Câu hỏi: ${question}
  Câu trả lời của ứng viên: ${answer}
  
  Hãy đánh giá dựa trên:
  - Điểm số (0-100)
  - Nhận xét chung (Feedback)
  - Điểm mạnh (Strengths - mảng 3 ý)
  - Điểm cần cải thiện (Improvements - mảng 3 ý)
  
  Trả về JSON:
  {
    "score": 85,
    "feedback": "...",
    "strengths": ["...", "...", "..."],
    "improvements": ["...", "...", "..."]
  }`;

  const response = await ai.models.generateContent({
    model,
    contents: prompt,
    config: { responseMimeType: "application/json" }
  });

  return JSON.parse(response.text);
}

export async function chatWithMentor(messages: { role: 'user' | 'model', content: string }[], userProfile: any) {
  const systemInstruction = `Bạn là một Mentor dày dặn kinh nghiệm (15 năm) trong ngành ${userProfile.goal}. 
  Bạn đang hỗ trợ sinh viên tên là ${userProfile.name}, hiện đang học năm ${userProfile.year} với GPA ${userProfile.gpa}.
  Phong cách: Chuyên nghiệp, thực tế, truyền cảm hứng, sử dụng ngôn ngữ ngành kinh tế.
  Nhiệm vụ: Tư vấn lộ trình, chọn chuyên ngành, kỹ năng (Excel, Power BI, SQL), CV, phỏng vấn, chứng chỉ, nghề nghiệp phù hợp.
  Luôn trả lời bằng Tiếng Việt, sử dụng Markdown, bullet points để dễ đọc. 
  Nếu sinh viên hỏi về việc cần làm, hãy gợi ý các task cụ thể.`;

  const chat = ai.chats.create({
    model,
    config: { systemInstruction }
  });

  // Convert history to parts
  const history = messages.slice(0, -1).map(m => ({
    role: m.role,
    parts: [{ text: m.content }]
  }));

  const lastMessage = messages[messages.length - 1].content;

  const response = await chat.sendMessage({
    message: lastMessage,
    history
  });

  return response.text;
}

export async function generateTasksFromChat(chatHistory: string, userGoal: string) {
  const prompt = `Dựa trên lịch sử trò chuyện sau, hãy trích xuất 3-5 nhiệm vụ (tasks) cụ thể mà sinh viên nên thực hiện để tiến gần hơn tới mục tiêu ${userGoal}.
  Lịch sử: ${chatHistory}
  
  Yêu cầu mỗi task có: tiêu đề, độ ưu tiên (low/medium/high), và deadline gợi ý (số ngày từ bây giờ).
  Trả về JSON:
  {
    "tasks": [
      { "title": "...", "priority": "high", "daysToDeadline": 7 },
      ...
    ]
  }`;

  const response = await ai.models.generateContent({
    model,
    contents: prompt,
    config: { responseMimeType: "application/json" }
  });

  return JSON.parse(response.text);
}

export async function generateDailyTip(userProfile: any) {
  const prompt = `Dựa trên hồ sơ sinh viên: ${userProfile.name}, mục tiêu ${userProfile.goal}, năm ${userProfile.year}.
  Hãy đưa ra 1 lời khuyên nghề nghiệp (Daily Tip) sâu sắc, thực tế cho ngành kinh tế hôm nay.
  Trả về JSON: { "tip": "..." }`;

  const response = await ai.models.generateContent({
    model,
    contents: prompt,
    config: { responseMimeType: "application/json" }
  });

  return JSON.parse(response.text);
}
