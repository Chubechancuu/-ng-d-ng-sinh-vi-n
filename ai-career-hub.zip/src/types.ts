export interface UserProfile {
  name: string;
  goal: string;
  year: string;
  gpa: string;
  onboarded?: boolean;
  xp: number;
  level: number;
  streak: number;
  focusTime: number; // in minutes
  completedTasks: number;
  badges: string[];
}

export interface Task {
  id: string;
  title: string;
  deadline: string;
  priority: 'low' | 'medium' | 'high';
  status: 'pending' | 'done';
  createdAt: number;
}

export interface ChatMessage {
  role: 'user' | 'model';
  content: string;
  timestamp: number;
}

export interface RoadmapItem {
  year: string;
  tasks: string[];
  advice: string;
  skills?: string[];
}

export interface Simulation {
  id: string;
  title: string;
  context: string;
  task: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  industry: string;
  options: {
    id: number;
    text: string;
    feedback: string;
  }[];
}

export interface SimulationEvaluation {
  isCorrect: boolean;
  score: number;
  explanation: string;
  proTip: string;
  skillsImproved: string[];
}

export interface InterviewEvaluation {
  score: number;
  feedback: string;
  strengths: string[];
  improvements: string[];
}

export interface CVData {
  personalInfo: {
    fullName: string;
    email: string;
    phone: string;
    address: string;
    summary: string;
  };
  education: {
    school: string;
    degree: string;
    major: string;
    startDate: string;
    endDate: string;
  }[];
  experience: {
    role: string;
    company: string;
    period: string;
    desc: string;
  }[];
  skills: string[];
  projects: {
    name: string;
    desc: string;
    link?: string;
  }[];
}
